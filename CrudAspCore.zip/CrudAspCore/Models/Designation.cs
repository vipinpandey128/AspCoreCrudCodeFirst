﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CrudAspCore.Models
{
    public class Designation
    {
        [Key]
        public int iDesignationID { get; set; }
        public string iDesignationName { get; set; }
        public bool iDesgStatus { get; set; }
        public DateTime iDesgCrDate { get; set; } = DateTime.Now;
    }
}
