﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CrudAspCore.Models
{
    public class Employee
    {
        [Key]
        public long iEmpId { get; set; }
        public string iEmpName { get; set; }
        public string iEmpAddress { get; set; }
        public string iEmpCompnayName { get; set; }
        public bool iEmpStatus { get; set; }
        public DateTime iEmpCreateDate { get; set; } = DateTime.Now;
    }
}
